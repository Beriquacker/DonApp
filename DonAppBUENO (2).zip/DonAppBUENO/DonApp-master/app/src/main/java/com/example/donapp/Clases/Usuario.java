package com.example.donapp.Clases;

public class Usuario {
    private Integer Id;

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    private String Name;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    private String Email;

    public String getCodPostal() {
        return CodPostal;
    }

    public void setCodPostal(String codPostal) {
        CodPostal = codPostal;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    private String CodPostal;
}
