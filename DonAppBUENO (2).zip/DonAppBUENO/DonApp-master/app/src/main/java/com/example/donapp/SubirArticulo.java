package com.example.donapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.donapp.BD.DBCode;

public class UploadArticleActivity extends AppCompatActivity {
    private EditText nameEditText;
    private EditText descriptionEditText;
    private Spinner stateSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_article);

        nameEditText = findViewById(R.id.name_edittext);
        descriptionEditText = findViewById(R.id.description_edittext);
        stateSpinner = findViewById(R.id.state_spinner);

        Button uploadButton = findViewById(R
                id.upload_button);

        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadArticle();
            }
        });
    }

    private void uploadArticle() {
        String name = nameEditText.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();
        String state = stateSpinner.getSelectedItem().toString();

        if (name.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Por favor, complete todos los campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Insertar el artículo en la base de datos
        DBCode dbHelper = new DBCode(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put("articulo", name);
        contentValues.put("descripcion", description);
        contentValues.put("Tipo", type);

        long newRowId = db.insert(DBCode.TABLE_TIENDA, null, contentValues);

        if (newRowId != -1) {
            Toast.makeText(this, "Artículo subido con éxito.", Toast.LENGTH_SHORT).show();
            finish(); // Cierra la actividad
        } else {
            Toast.makeText(this, "Error al subir el artículo. Intente de nuevo.", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }
}
