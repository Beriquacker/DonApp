El equipo de Arcadyan está compuesto por estudiantes universitarios que buscamos resolver un problema fundamental que hemos identificado en nuestra sociedad con el objetivo de producir un cambio positivo en el mundo. 
Para lograr esto hemos decidido crear un software, específicamente una aplicación movil llamada DonApp, esta será accesible por cualquier individuo que posea un móvil y estará creada con un diseño intuitivo y fácil de usar. 
La aplicación permitirá que el usuario ponga a disposición cualquier tipo de producto para ser donado, y se podrá donar directamente a ciertas ONGs registradas en la app, por ejemplo, ropa, juguetes o libros (sólo excluyendo productos alimenticios).
Por último, la aplicación contará con un servicio de mensajería para que los usuarios y las ONGs tengan la capacidad de ponerse en contacto. 
Creemos que otro mundo es posible, buscamos evitar el consumo innecesario y sus consecuencias negativas en el medio ambiente y preservar nuestros valores como sociedad.
 
